﻿<?php
    include("inculde/connection.php");
	if(isset($_GET['id'])){
	$newid=$_GET['id'];
    $query="Delete FROM items where item_id = $newid";
	mysqli_query($con,$query);
	header('location:index.php');
	}
					