<?php
    $con=mysqli_connect("localhost","root","","inventory");
    if(!$con){
    	die("connection error".mysqli_connect_error());
    }
?>